// Select color input
// Select size input

// When size is submitted by the user, call makeGrid()
var height;
var width;
var color;

function makeGrid(height, width) {
    $('tr').remove();
    // in order to erase an existing grid without reloading the page
    for (i=1; i<=height; i++){
        $('#pixelCanvas').append('<tr id=table' + i + '></tr>');
        for (h=1; h<= width; h++){
            $('#table' + i).append('<td></td>')}
        }
     

    $('td').click(function colorIn() {
        color = $('#colorPicker').val()
        // console.log(color)
        if ($(this).attr('style')){
            $(this).removeAttr('style')
        } else {
            $(this).attr('style', 'background-color:' + color);

        }
    })
}

$('#sizePicker').submit(function(e){
    e.preventDefault();
    height= $('#inputHeight').val();
    width= $('#inputWidth').val();
   // console.log(height,width);
    makeGrid(height, width)
})


 